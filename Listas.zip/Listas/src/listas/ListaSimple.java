package listas;
public class ListaSimple {
    NodoS p;

    public ListaSimple() {
        p=null;
    }
    
}
