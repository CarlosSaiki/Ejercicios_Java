package listas;

public class NodoS {

    int dato;

    NodoS sig;

    public NodoS() {
        sig = null;
    }

}

